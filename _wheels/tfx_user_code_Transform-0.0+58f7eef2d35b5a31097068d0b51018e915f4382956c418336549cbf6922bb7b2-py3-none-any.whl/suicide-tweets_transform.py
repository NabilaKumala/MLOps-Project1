
import tensorflow_transform as tft
import tensorflow as tf

LABEL_KEY = "Suicide"
FEATURE_KEY = "Tweet"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    outputs = {}
    
    # outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    
    # Convert sparse tensor to dense tensor
    dense_feature = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')
    
    # Compute the maximum length of the tweets
    max_tweet_length = tf.math.reduce_max(tf.strings.length(dense_feature))
    
    # Pad or truncate tweets to the maximum length
    dense_feature = tf.strings.right_pad(dense_feature, paddings=[[0, 0], [0, max_tweet_length]])
    dense_feature = tf.strings.substr(dense_feature, 0, max_tweet_length)
    
    # Apply lowercasing
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(dense_feature)
    
    # Cast label to int64
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    
    return outputs
